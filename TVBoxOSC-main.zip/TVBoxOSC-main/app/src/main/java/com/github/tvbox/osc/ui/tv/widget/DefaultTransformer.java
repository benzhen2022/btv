package com.github.tvbox.osc.ui.tv.widget;

import android.view.View;

import androidx.viewpager.widget.ViewPager;

/**
 * @author acer
 * @date 2018/8/22 11:46
 */
public class DefaultTransformer implements ViewPager.PageTransformer{
    @Override
    public void transformPage(View page, float position) {
    }
}
